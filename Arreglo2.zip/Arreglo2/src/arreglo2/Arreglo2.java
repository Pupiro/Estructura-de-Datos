/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arreglo2;

/**
 *
 * @author lopez
 */
public class Arreglo2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int num1 = 5;
        float flotante = 26.45f;
        boolean booleana = true;
        String cadena = "hoy es un dia";
        char caracter = 'A';

        int edad[] = new int[3];
        int[] numeros = new int[num1]; //establesco una variable que define el tamaño
        int[] alterno = new int[num1]; //establesco una variable que define el tamaño
        String[] estudiantes = new String[]{"Luis", "Jose", "Juan", "Emmanuel"};

        num1 = 5; //esta variable hace que el arreglo comience de 0
        numeros[0] = 10;
        numeros[1] = 30;
        numeros[2] = 40;
        for (int i = 0; i < 5; i++) {
            System.out.println("numeros: " + numeros[i]);
            alterno[i]=numeros[i]; //arreglo alterno almacena el arreglo anterior
        }

        num1 = 10; //esta variable hace que el arreglo comience de 0
        numeros = new int[num1];
        System.out.println("*********************************");
        for (int i = 0; i < 10; i++) {
           if(i<=4)
           {
               numeros[i]=alterno[i]; //el arreglo almacenado es pasado al segundo arreglo
           }
            System.out.println("numeros: " + numeros[i]);
        }

        edad[0] = 20;
        edad[1] = 30;
        edad[2] = 22;

        float promedio=0;
        float sumatoria=0;
        
        for (int i = 0; i < edad.length; i++) {
            sumatoria+=edad[i];
        }
        promedio/=edad.length;
        
        System.out.println("Promedio: "+promedio);
        
        System.out.println(estudiantes.length);

        for (int i = 0; i < estudiantes.length; i++) {
            System.out.println("Los estudiantes son: " + (i + 1));
        }
        
        for (int i = 3; i >-1; i--) {
            System.out.println("Estudiantes inversa: "+"("+(i+1)+"): "+estudiantes[i]);
        }
    }

}
