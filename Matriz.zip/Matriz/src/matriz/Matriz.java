/*
Emmanuel Lopez Pupiro
suma de diagonales
 */
package matriz;

/**
 *
 * @author lopez
 */
public class Matriz {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int [][] matriz = new int [5][5];
        int cont=1;
        int sumatoria=0;
        
      /*for (int i = 0; i < 3; i++)  //filas
        {
            for (int j = 0; j < 3; j++) //columnas
            {
             matriz [i][j]=cont++;
               sumatoria=sumatoria+matriz[i][j];
            }
         }
         System.out.println("Sumatoria matriz: "+sumatoria);*/
        
                
         for (int i = 4; i >=0 ; i--)  //filas
        {
            for (int j = 4; j >=0; j--) //columnas
            {
               if((i+j)==4) //la suma de la posicion fila y columna es igual a 2 por lo tanto se condiciona usando esta logica.
                {
                            sumatoria+=cont; //suma de columnas o filas segun criterios
                }
              matriz[i][j]=cont++;
            }
        }
                 System.out.println("Sumatoria matriz: "+sumatoria);
                 
        for (int i = 0; i < 5; i++)  //filas
        {
            for (int j = 0; j < 5; j++) //columnas
            {
                System.out.print("   "+matriz[i][j]);
                
            }
            System.out.println("  ");
        }
        
        
    }
    
}
